from fastapi.testclient import TestClient
import pytest
from app.main import app

client = TestClient(app)

def test_upload_pdf():
    # Open a sample PDF for testing
    with open("sample.pdf", "rb") as pdf_file:
        response = client.post("/upload-pdf/", files={"file": pdf_file})
    assert response.status_code == 200
    assert "filename" in response.json()

def test_websocket_question():
    with client.websocket_connect("/ws/question/") as websocket:
        websocket.send_text("1|What is the content of the PDF?")
        data = websocket.receive_text()
        assert "Answer for" in data
