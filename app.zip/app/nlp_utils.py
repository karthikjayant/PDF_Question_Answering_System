from transformers import pipeline
from .database import documents, database

# Load the question-answering pipeline (you may want to initialize this once at startup for efficiency)
qa_pipeline = pipeline("question-answering")

async def get_answer_from_pdf(document_id: int, question: str) -> str:
    # Retrieve the document content from the database
    query = documents.select().where(documents.c.id == document_id)
    result = await database.fetch_one(query)
    text_content = result["text_content"] if result else ""

    # Use the question-answering pipeline to find the answer
    if text_content:
        answer = qa_pipeline({
            "context": text_content,
            "question": question
        })
        return answer["answer"]
    else:
        return "No content available for this document."
