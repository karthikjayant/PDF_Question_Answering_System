from fastapi import FastAPI, WebSocket, UploadFile, HTTPException
from .database import init_db
from .pdf_utils import save_pdf
from .nlp_utils import get_answer_from_pdf


app = FastAPI()

@app.on_event("startup")
async def startup():
    await init_db()

@app.post("/upload-pdf/")
async def upload_pdf(file: UploadFile):
    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="File must be a PDF.")
    response = await save_pdf(file, file.filename)
    return response

@app.websocket("/ws/question/")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()  # Ensure the connection is accepted
    while True:
        try:
            data = await websocket.receive_text()
            document_id, question = data.split("|", 1)
            answer = await get_answer_from_pdf(int(document_id), question)
            await websocket.send_text(answer)
        except Exception as e:
            print(f"Error: {e}")
            await websocket.close()
            break