import os
import fitz  # PyMuPDF
from .database import documents, database


async def extract_text_from_pdf(file_path: str) -> str:
    text_content = ""
    with fitz.open(file_path) as pdf:
        for page in pdf:
            text_content += page.get_text()
    return text_content

async def save_pdf(file, filename: str):
    # Ensure the temp directory exists
    os.makedirs("temp", exist_ok=True)
    
    # Save the file to the temp directory
    file_location = f"temp/{filename}"
    with open(file_location, "wb") as f:
        f.write(await file.read())

    # Extract text content
    text_content = await extract_text_from_pdf(file_location)
    
    # Insert the document metadata and text content into the database
    query = documents.insert().values(filename=filename, text_content=text_content)
    inserted_id = await database.execute(query)  # This returns the inserted ID for SQLite with `databases`

    # Return the filename and the document ID
    return {"filename": filename, "document_id": inserted_id}

