from databases import Database
from sqlalchemy import create_engine, MetaData, Table, Column, Integer, String, DateTime
from datetime import datetime

DATABASE_URL = "sqlite:///./test.db"

database = Database(DATABASE_URL)
metadata = MetaData()

# Define the documents table schema
documents = Table(
    "documents",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("filename", String, index=True),
    Column("upload_date", DateTime, default=datetime.utcnow),
    Column("text_content", String)
)

engine = create_engine(DATABASE_URL)
metadata.create_all(engine)

async def init_db():
    await database.connect()
